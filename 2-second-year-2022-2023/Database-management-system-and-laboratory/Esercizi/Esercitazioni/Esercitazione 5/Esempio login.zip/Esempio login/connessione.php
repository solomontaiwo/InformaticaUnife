<?php

	$link = mysqli_connect("127.0.0.1", "giacomo", "password", "test");

	// Controllo se è avvenuta la connessione al database:
	if (!$link) {
	    echo "Si è verificato un errore: Non riesco a collegarmi al database" . PHP_EOL;
	    echo "Codice errore: " . mysqli_connect_errno() . PHP_EOL;
	    echo "Messaggio errore: " . mysqli_connect_error() . PHP_EOL;
	    exit;
	}

?>