<?php

// In ogni pagina protetta, controllo se esiste una sessione per l'utente.
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
}

?>

<!DOCTYPE html>
<html lang="it">
    
    <head>
        <meta charset="utf-8">
        <title>Pagina protetta</title>

		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/water.css@2/out/water.css">
		<style> body { max-width: 1200px; } </style>		
    </head>

    <body>
		<p>Pagina protetta da password</p>
		<a href="logout.php">Log out</a>
    </body>
	
</html>
