<?php

// Nel database la password cifrata ha questo valore: 5f4dcc3b5aa765d61d8327deb882cf99
// La password non cifrata è 'password'

// Attivo la sessione	
session_start();

// Eseguo la connesione al database
include_once('connessione.php');

// Raccolgo username e password inserite dall'utente
if (isset($_POST['username']))
	$username = $_POST['username'];

if (isset($_POST['password']))
	$password = $_POST['password'];

// Se entrambe sono state inserite allora proseguo 
if (isset($username) && isset($password)) {
	
	// Preparo la query per cercare un utente con la username inserita
    $sql = "SELECT * FROM users WHERE username = '$username'";

	// Eseguo la query 
    $result = mysqli_query($link, $sql);
	
	if ($result) {
		// Se esistono risultati allora esiste un utente con la username inserita.
		$row = mysqli_fetch_array($result);
		
		// Procedo al controllo della password:
		// All'internod el database, per sicurezza, la password è memorizzata cifrata, non posso quindi confrontarla con la password in chiaro inserita dall'utente. 
		// Procedo quindi a controllare se le password cifrate coincidono:
		if (md5($password) == $row['password']) {
    		// Se le password coincidono allora inserisco in sessione l'id dell'utente, la sola presenza 
			// di quel parametro, che potrebbe benissimo essere qualcos'altro come ad esempio l'email 
			// garantisce che questa riga di codice è stata eseguita e che quindi l'utente ha fatto l'accesso
			$_SESSION['user_id'] = $row['id'];

			// Chiudo la connessione al database 
			mysqli_close($link);

			// Posso quindi reindirizzare l'utente alla pagina "protetta"
			header("Location: index.php");	
			exit();
		}		
	}

	// Chiudo la connessione al database 
	mysqli_close($link);

	// Se arrivo qui, la password o non coincide oppure non c'è nessun utente con la username inserita
	// Reindirizzo l'utente alla pagina di login
	header("Location: login.html");	

} else {
	// Se non sono stati isneriti username e password allora reindirizzo l'utente alla pagina di login
	header("Location: login.html");	
}

?>
