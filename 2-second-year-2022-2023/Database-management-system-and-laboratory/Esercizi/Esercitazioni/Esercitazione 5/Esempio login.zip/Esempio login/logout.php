<?php

// La pagina di logout distrugge la sessione
session_start();
session_destroy();

// Reindirizzo l'utente alla pagina di login
header("Location: login.html");	

?>
