# BibliotecaUNIFE

Repository del [progetto](/Traccia_progetto.pdf) a conclusione dell'insegnamento di Basi di Dati (a.a. 2022/23) del corso di Informatica presso l'Università degli Studi di Ferrara.

Nota: per far funzionare correttamente le query in ""SQL/Script/Inserimento_dati.sql" potrebbe essere necessario che, in Mysql, la connessione venga editata per permettere il caricamento dei dati: nello specifico, occorre andare in ‘edit connection’ - ‘advanced’ ed inserire la linea “OPT_LOCAL_INFILE=1” (senza virgolette) nel riquadro ‘Others’. Dopo averlo fatto, modificare i percorsi assoluti dei file .csv da caricare nel database creato con le query dello script "Creazione_schema.sql".

Gruppo n. 6, Gaia Marzola - Solomon Olamide Taiwo
