from progetto import Progetto

class Innovazione(Progetto):
    numero_aziende: int

    def __init__(self, codice: int, tipo: str, titolo: str, coordinatore: str, organizzazione: str, importo: float, numero_aziende: int):
        super().__init__(codice, tipo, titolo, coordinatore, organizzazione, importo)
        self.numero_aziende = numero_aziende

    def __str__(self):
        return super().__str__() + ", -, -, " + str(self.numero_aziende) + ", " + str(self.get_importo())