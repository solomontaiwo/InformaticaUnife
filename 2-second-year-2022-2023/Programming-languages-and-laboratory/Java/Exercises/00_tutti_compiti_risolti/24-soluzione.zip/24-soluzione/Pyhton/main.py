import argparse

from progetto import Progetto
from ricerca import Ricerca
from innovazione import Innovazione
from ricercatore import Ricercatore
from partecipazione import Partecipazione

def main(args):
    progetti: list[Progetto] = []
    ricercatori: list[Ricercatore] = []

    progetto_dict = {}

    # PUNTO 1: lettura progetti.txt
    try:
        file = open("progetti.txt", "r", encoding='utf-8') # per leggere correttamente i caratteri accentati

        line = file.readline().strip()

        while line != "":
            splitted_line = line.split()

            codice = int(splitted_line[0])
            tipo = splitted_line[1]

            titolo = file.readline().strip()

            coordinatore = file.readline().strip()

            organizzazione = file.readline().strip()

            line = file.readline().strip()
            if tipo == "ricerca":
                splitted_line = line.split()

                codice_argomento = splitted_line[0]
                numero_partner = int(splitted_line[1])
                importo = float(file.readline().strip())

                ricerca = Ricerca(codice, tipo, titolo, coordinatore, organizzazione, importo, codice_argomento, numero_partner)
                progetti.append(ricerca)
                progetto_dict[codice] = ricerca

            elif tipo == "innovazione":
                splitted_line = line.split()

                numero_aziende = splitted_line[0]
                importo = float(splitted_line[1])

                innovazione = Innovazione(codice, tipo, titolo, coordinatore, organizzazione, importo, numero_aziende)
                progetti.append(innovazione)
                progetto_dict[codice] = innovazione

            line = file.readline().strip()

        file.close()
    except IOError as io_exception:
        print(io_exception)
    except Exception as e:
        print(e)
    
    # PUNTO 2: lettura file ricercatori.txt
    try:
        file = open("ricercatori.txt", "r", encoding='utf-8')
        
        line = file.readline().strip()

        while line != "":
            nome = line
            cognome = file.readline().strip()

            ricercatore = Ricercatore(nome, cognome)
            ricercatori.append(ricercatore)

            line = file.readline().strip()
            while line != "" and line != "\n":
                splitted_line = line.split()

                codice_progetto = int(splitted_line[0])
                impegno = float(splitted_line[1])

                progetto = progetto_dict[codice_progetto]

                partecipazione = Partecipazione(progetto, impegno)

                ricercatore.add_partecipazione(partecipazione)

                line = file.readline().strip()
            line = file.readline().strip()

        file.close()
    except IOError as io_exception:
        print(io_exception)
    except Exception as e:
        print(e)

    # PUNTO 3: stampa progetti
    print("tipo, titolo, codice, coordinatore, organizzazione, argomento, partner, aziende, importo totale in migliaia di euro")

    for progetto in progetti:
        print(progetto)

    print("\n\n")

    # PUNTO 4: stampa ricercatori
    for ricercatore in ricercatori:
        print(ricercatore)

    print("\n\n")

    # PUNTO 5
    flag = False
    for ricercatore in ricercatori:
        if ricercatore.cognome == args.cognome:
            flag = True
            partecipazione = ricercatore.get_impegno_maggiore()
            print(ricercatore.nome, ricercatore.cognome, partecipazione.impegno_orario, partecipazione.progetto.titolo)

    if not flag:
        print("Cognome non trovato.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()

    parser.add_argument("--cognome", "-c", required = True)

    args = parser.parse_args()
    main(args)