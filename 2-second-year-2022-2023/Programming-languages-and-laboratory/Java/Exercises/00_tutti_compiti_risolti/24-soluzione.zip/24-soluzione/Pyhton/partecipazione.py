from progetto import Progetto

class Partecipazione:
    progetto: Progetto
    impegno_orario: float #Python non ha il tipo Double

    def __init__(self, progetto: Progetto, impegno_orario: float):
        self.progetto = progetto
        self.impegno_orario = impegno_orario

    def __str__(self) -> str:
        return str(self.progetto.codice) + ", " + str(self.impegno_orario)