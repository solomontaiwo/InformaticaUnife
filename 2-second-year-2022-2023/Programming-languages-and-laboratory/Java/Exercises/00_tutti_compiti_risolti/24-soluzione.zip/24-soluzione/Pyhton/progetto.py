class Progetto:
    codice: int
    tipo: str
    titolo: str
    coordinatore: str
    organizzazione: str
    importo: float #Python non ha il tipo Double

    def __init__(self, codice: int, tipo: str, titolo: str, coordinatore: str, organizzazione: str, importo: float):
        self.codice = codice
        self.tipo = tipo
        self.titolo = titolo
        self.coordinatore = coordinatore
        self.organizzazione = organizzazione
        self.importo = importo

    def get_importo(self) -> float:
        return self.importo * 1000

    def __str__(self):
        return self.tipo + ", " + self.titolo + ", " + str(self.codice) + ", " + self.coordinatore + ", " + self.organizzazione