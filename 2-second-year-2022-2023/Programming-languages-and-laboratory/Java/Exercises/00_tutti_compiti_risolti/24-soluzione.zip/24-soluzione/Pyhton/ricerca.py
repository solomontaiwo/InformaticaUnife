from progetto import Progetto

class Ricerca(Progetto):
    codice_argomento: str
    numero_partner: int

    def __init__(self, codice: int, tipo: str, titolo: str, coordinatore: str, organizzazione: str, importo: float, codice_argomento: str, numero_partner: int):
        super().__init__(codice, tipo, titolo, coordinatore, organizzazione, importo)
        self.codice_argomento = codice_argomento
        self.numero_partner = numero_partner
        
    def __str__(self):
        return super().__str__() + ", " + self.codice_argomento + ", " + str(self.numero_partner) + ", -, " + str(self.get_importo())