from partecipazione import Partecipazione

class Ricercatore:
    nome: str
    cognome: str
    partecipazioni: list[Partecipazione]

    def __init__(self, nome: str, cognome: str, partecipazioni: list[Partecipazione] = None):
        self.nome = nome
        self.cognome = cognome
        if partecipazioni is None:
            self.partecipazioni = []
        else:
            self.partecipazioni = partecipazioni

    def add_partecipazione(self, partecipazione: Partecipazione):
        self.partecipazioni.append(partecipazione)

    def get_impegno_totale(self):
        tot = 0
        for partecipazione in self.partecipazioni:
            tot = tot + partecipazione.impegno_orario
        
        return tot

    def get_impegno_maggiore(self):
        result: Partecipazione = None
        max = 0
        for partecipazione in self.partecipazioni:
            if partecipazione.impegno_orario > max:
                max = partecipazione.impegno_orario
                result = partecipazione
        return result

    def __str__(self) -> str:
        return self.nome + ", " + self.cognome + ", " + str(self.get_impegno_totale()) + ", " + str(len(self.partecipazioni)) + ", " + str(list(map(str, self.partecipazioni)))