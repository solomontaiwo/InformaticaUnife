from Veicolo import Veicolo



class Caravan(Veicolo):
    def __init__(self, codice, nome,  larghezza,  lunghezza,costo, posti,potenza):
        super().__init__(codice, nome,  larghezza,  lunghezza,costo, posti)

        self._potenza = potenza

            
    def __str__(self):
        return "caravan\t"+super().__str__() + "-\t-\t"+str(self._potenza) + "\t" + str(self._costo)