class Cliente:
    def __init__(self, codice, nome,cognome, indirizzo):
        self._codice = codice
        self._nome = nome
        self._cognome = cognome
        self._indirizzo=indirizzo
        self._prenotazioni = []

    def addPrenotazione(self, pren):
        self._prenotazioni.append(pren)


    def __str__(self):
        return str(self._codice)+"\t"+self._cognome + "\t"+self._nome + "\t"  + self._indirizzo+"\t"+str([str(pren) for pren in self._prenotazioni])
