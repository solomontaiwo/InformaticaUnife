from Veicolo import Veicolo


class Roulotte(Veicolo):
    def __init__(self,codice, marca,  larghezza,  lunghezza,   costo, posti, peso, veranda):
        super().__init__(codice, marca,  larghezza,  lunghezza,costo, posti)
        self._peso= peso
        self._veranda = veranda



    def __str__(self):
        return "roulotte\t"+super().__str__() + str(self._peso) + "\t" + self._veranda+ "\t-\t" + str(self._costo)
