


class Veicolo:
    def __init__(self, codice, marca,  larghezza,  lunghezza,   costo, posti):
        self._codice = codice
        self._marca=marca
        self._larghezza = larghezza
        self._lunghezza = lunghezza
        self._costo=costo
        self._posti=posti
        self._prenotazioni = []

    def addPrenotazione(self, prenotazione):
    	self._prenotazioni.append(prenotazione);	
    def incasso(self):
        giorni=0
        for p in self._prenotazioni:
            giorni=giorni+p.getGiorni()
        return giorni*self._costo
 
    def getCod(self):
        return self._codice

    def __str__(self):
        return str(self._codice) + "\t" +self._marca+"\t"+str(self._larghezza)+"\t"+str(self._lunghezza)+"\t"+str(self._posti)+"\t"
