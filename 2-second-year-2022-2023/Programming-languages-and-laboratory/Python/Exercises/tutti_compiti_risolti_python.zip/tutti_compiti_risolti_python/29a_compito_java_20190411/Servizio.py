class Servizio:
    def __init__(self, codice_dipendente, ore):
        self._codice_dipendente = codice_dipendente
        self._ore = ore
