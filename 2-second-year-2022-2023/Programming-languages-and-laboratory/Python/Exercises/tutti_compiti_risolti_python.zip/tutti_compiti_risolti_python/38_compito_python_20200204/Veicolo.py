class Veicolo:
    def __init__(self, codice, sport, marca, lunghezza, larghezza, posti_letto, costo_giornaliero):
        self._codice = codice
        self._sport = sport
        self._marca = marca
        self._lunghezza = lunghezza
        self._larghezza = larghezza
        self._posti_letto = posti_letto
        self._costo_giornaliero = costo_giornaliero
