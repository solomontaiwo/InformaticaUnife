<?php

namespace App\Http\Controllers;

class ExhibitionController extends Controller
{
    public function index()
    {
        return view('exhibition');
    }
}
