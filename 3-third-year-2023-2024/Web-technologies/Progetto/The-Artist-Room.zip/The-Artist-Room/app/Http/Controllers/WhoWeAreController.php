<?php

namespace App\Http\Controllers;

class WhoWeAreController extends Controller
{
    public function index()
    {
        return view('who-we-are');
    }
}
