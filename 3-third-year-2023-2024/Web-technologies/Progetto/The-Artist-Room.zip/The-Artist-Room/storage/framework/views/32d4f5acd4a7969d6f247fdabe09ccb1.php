<?php $__env->startSection('content'); ?>

<div class="container">

    <h1>Dettagli prenotazione</h1>

    <hr>

    <p><strong>Aula:</strong> <?php echo e($booking->room->name); ?></p>
    <p><strong>Giorno di arrivo:</strong> <?php echo e(\Carbon\Carbon::parse($booking->arrival_date)->format('d/m/Y')); ?></p>
    <p><strong>Orario di arrivo:</strong> <?php echo e(\Carbon\Carbon::parse($booking->arrival_time)->format('H:i')); ?></p>
    <p><strong>Giorno di partenza:</strong> <?php echo e(\Carbon\Carbon::parse($booking->departure_date)->format('d/m/Y')); ?></p>
    <p><strong>Orario di partenza:</strong> <?php echo e(\Carbon\Carbon::parse($booking->departure_time)->format('H:i')); ?></p>
    <p><strong>Numero di persone:</strong> <?php echo e($booking->people); ?></p>

    <?php if(auth()->check() && auth()->user()->is_admin): ?>
    <p><strong>Data e ora creazione prenotazione:</strong> <?php echo e($booking->created_at); ?></p>
    <?php endif; ?>

    <hr>
    <a href="<?php echo e(route('bookings.edit', $booking->id)); ?>" class="btn btn-warning btn-sm me-2">Modifica prenotazione</a>
    <a href="<?php echo e(route('bookings.index')); ?>" class="btn btn-primary btn-sm me-2">Vai alle tue prenotazioni</a>
    <a href="<?php echo e(route('home')); ?>" class="btn btn-primary btn-sm">Torna alla homepage</a>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/solomontaiwo/Documents/The-Artist-Room/resources/views/bookings/show.blade.php ENDPATH**/ ?>