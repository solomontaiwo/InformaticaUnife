<?php $__env->startSection('content'); ?>

<div class="container">
    <h1>Prenotazioni di <?php echo e($user->name); ?> <?php echo e($user->surname); ?></h1>
    <br>
    <h3>Prenotazioni totali: <?php echo e($user->bookings->count()); ?> </h3>

    <?php if($user->bookings->isEmpty()): ?>
    <p>L'utente non ha ancora effettuato prenotazioni.</p>
    <?php else: ?>
    <ul>
        <?php $__currentLoopData = $user->bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>

            <br>

            <p><strong>Nome stanza:</strong> <?php echo e($booking->room->name); ?></p>
            <p><strong>Data di arrivo:</strong> <?php echo e(\Carbon\Carbon::parse($booking->arrival_date)->format('d/m/Y')); ?></p>
            <p><strong>Orario di arrivo:</strong> <?php echo e(\Carbon\Carbon::parse($booking->arrival_time)->format('H:i')); ?></p>
            <p><strong>Data di partenza:</strong> <?php echo e(\Carbon\Carbon::parse($booking->departure_date)->format('d/m/Y')); ?></p>
            <p><strong>Orario di partenza:</strong> <?php echo e(\Carbon\Carbon::parse($booking->departure_time)->format('H:i')); ?></p>
            <p><strong>Persone:</strong> <?php echo e($booking->people); ?></p>

            <!-- Pulsante per modificare la prenotazione -->
            <a href="<?php echo e(route('bookings.edit', $booking->id)); ?>" class="btn btn-warning">Modifica prenotazione</a>

            <br> <br>
            <hr>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/solomontaiwo/Documents/The-Artist-Room/resources/views/users/show.blade.php ENDPATH**/ ?>