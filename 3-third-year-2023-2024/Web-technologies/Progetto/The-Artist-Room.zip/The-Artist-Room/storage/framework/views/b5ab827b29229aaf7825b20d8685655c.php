<?php $__env->startSection('content'); ?>

<div class="container">
    <h1>Tutte le aule</h1>

    <hr>

    <h3> Aule totali: <?php echo e($rooms->count()); ?> </h3>

    <?php if($rooms->isEmpty()): ?>
    <p>Nessuna aula disponibile.</p>
    <?php else: ?>
    <ul>
        <!--foreach per stmpare le aule -->
        <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>

            <br>

            <!-- Informazioni sull'aula -->
            <p>Nome aula: <?php echo e($room->name); ?></p>
            <p>Tipo: <?php echo e($room->description); ?></p>
            <p>Indirizzo: <?php echo e($room->address); ?></p>
            <p>Dimensioni: <?php echo e($room->size); ?> mq</p>
            <p>Posti attualmente disponibili: <?php echo e($room->available_seats); ?></p>

            <!-- Pulsante per modificare l'aula, si vede solo se l'utente è un admin -->
            <?php if(auth()->check() && auth()->user()->is_admin): ?>
            <a href="<?php echo e(route('rooms.edit', $room->id)); ?>" class="btn btn-warning btn-sm">Modifica aula</a>
            <br>
            <?php endif; ?>

            <br>
            <hr>
            </form>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/solomontaiwo/Documents/The-Artist-Room/resources/views/rooms/index.blade.php ENDPATH**/ ?>