<?php $__env->startSection('content'); ?>

<div class="container">
    <h1>Dettagli aula</h1>

    <hr>

    <p><strong>Aula:</strong> <?php echo e($room->name); ?></p>
    <p><strong>Descrizione:</strong> <?php echo e($room->description); ?></p>
    <p><strong>Indirizzo:</strong> <?php echo e($room->address); ?></p>
    <p><strong>Dimensioni:</strong> <?php echo e($room->size); ?> mq</p>
    <p><strong>Posti attualmente disponibili:</strong> <?php echo e($room->available_seats); ?></p>

    <hr>

    <?php if(auth()->check() && auth()->user()->is_admin): ?>
    <p><a href="<?php echo e(route('rooms.edit', $room->id)); ?>" class="btn btn-warning btn-sm">Modifica aula</a></p>
    <?php endif; ?>
    <p><a href="<?php echo e(route('rooms.index')); ?>" class="btn btn-primary btn-sm">Vedi tutte le aule</a></p>
    <p><a href="<?php echo e(route('home')); ?>" class="btn btn-primary btn-sm">Torna alla homepage</a></p>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/solomontaiwo/Documents/The-Artist-Room/resources/views/rooms/show.blade.php ENDPATH**/ ?>