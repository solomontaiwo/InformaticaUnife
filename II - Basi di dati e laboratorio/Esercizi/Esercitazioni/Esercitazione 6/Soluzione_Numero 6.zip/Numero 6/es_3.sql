-- a
INSERT INTO STUDENTE VALUES (‘Johnson’, 25, 1, ‘MATH’)

-- b
UPDATE STUDENTE SET Anno_Corso = 2 WHERE Nome=’Smith’

-- c
INSERT INTO INSEGNAMENTO VALUES (Ingegneria della Conoscenza’,’CS4390’, 3,’CS’)

-- d
DELETE FROM STUDENTE WHERE Nome=’Smith’ AND Numero_Studente=17
