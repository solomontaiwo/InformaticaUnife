CREATE DATABASE Televisione;
USE Televisione;

CREATE TABLE Programmi(
	Codice VARCHAR (5) NOT NULL,
	NomeProgramma VARCHAR(50),
	Rete VARCHAR(50), 
	Tipologia VARCHAR(50),
	
	PRIMARY KEY (Codice)
);

CREATE TABLE Artisti(
	CProgramma VARCHAR(5) NOT NULL,
	NomeArt VARCHAR(50) NOT NULL,
	
	PRIMARY KEY (CProgramma, NomeArt),
	FOREIGN KEY (CProgramma) REFERENCES Programmi(Codice)
);

CREATE TABLE Sondaggi(
	CodProg VARCHAR(5) NOT NULL,
	Auditel INT,
	
	PRIMARY KEY (CodProg),
	FOREIGN KEY (CodProg) REFERENCES Programmi (Codice)
);

INSERT INTO Programmi VALUES ('A23', 'Ulisse - Il piacere della scoperta', 'Rai2', 'Documentario');
INSERT INTO Programmi VALUES ('P17', 'Ciao Darwin 8 - Terre Desolate', 'Canale 5', 'Varietà');
INSERT INTO Programmi VALUES ('C32', 'Che tempo che fa', 'Rai1', 'Late show');
INSERT INTO Programmi VALUES ('F24', '4 Ristoranti', 'TV 8', 'Cucina');

INSERT INTO Artisti VALUES ('A23', 'Alberto Angela');
INSERT INTO Artisti VALUES ('A23', 'Piero Angela');
INSERT INTO Artisti VALUES ('P17', 'Paolo Bonolis');
INSERT INTO Artisti VALUES ('P17', 'Luca Laurenti');
INSERT INTO Artisti VALUES ('C32', 'Fabio Fazio');
INSERT INTO Artisti VALUES ('C32', 'Luciana Litizzetto');
INSERT INTO Artisti VALUES ('C32', 'Filippa Lagerback');
INSERT INTO Artisti VALUES ('F24', 'Alessandro Borghese');

INSERT INTO Sondaggi VALUES ('A23', 91);
INSERT INTO Sondaggi VALUES ('P17', 79);
INSERT INTO Sondaggi VALUES ('C32', 63);
INSERT INTO Sondaggi VALUES ('F24', 54);

--1.a
SELECT Auditel
FROM Sondaggi
WHERE CodProg='P17';

--1.b
SELECT Auditel
FROM Sondaggi AS S, Artisti AS A
WHERE S.CodProg=A.CProgramma 
	AND A.NomeArt='Fabio Fazio';

--1.c
SELECT NomeProgramma
FROM Programmi AS P, Artisti AS A
WHERE P.Codice = A.CProgramma
	GROUP BY A.CProgramma
		HAVING COUNT(A.NomeArt) >= 2 
