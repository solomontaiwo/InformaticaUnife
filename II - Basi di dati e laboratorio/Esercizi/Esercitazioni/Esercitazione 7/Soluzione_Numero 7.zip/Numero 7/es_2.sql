CREATE DATABASE Elezioni;
USE Elezioni;

CREATE TABLE Partiti (
	Codice CHAR(3) NOT NULL,
	NomePartito VARCHAR(50) NOT NULL,
	Coalizione VARCHAR(50) DEFAULT NULL, 

	PRIMARY KEY(Codice)
);

CREATE TABLE Candidati (
	CPartito CHAR(3) NOT NULL,
	Citta VARCHAR(30) NOT NULL,
	NomeCand VARCHAR(30) NOT NULL,

	PRIMARY KEY(CPartito, Citta),
	FOREIGN KEY(CPartito) REFERENCES Partiti(Codice) ON UPDATE CASCADE
);

CREATE TABLE Sondaggi (
	CodPart CHAR(3) NOT NULL,
	PercFavorevoli  INT,

	PRIMARY KEY(CodPart),
	FOREIGN KEY(CodPart) REFERENCES Partiti(Codice)
);

INSERT INTO Partiti VALUES ("A01", "Forza Italia", "Centro Destra");
INSERT INTO Partiti VALUES ("A09", "PD", "Centro Sinistra");
INSERT INTO Partiti VALUES ("A21", "Forza Nuova", '');
INSERT INTO Partiti VALUES ("A13", "Lega", "Centro Destra");
INSERT INTO Partiti VALUES ("A42", "Fratelli d'Italia", "Centro Destra");

INSERT INTO Candidati VALUES ("A01", "Milano", "Rumantino");
INSERT INTO Candidati VALUES ("A01", "Ferrara", "Rossi");
INSERT INTO Candidati VALUES ("A01", "Venezia", "Verdi");
INSERT INTO Candidati VALUES ("A09", "Milano", "Bianchi");
INSERT INTO Candidati VALUES ("A42", "Ferrara", "Neri");
INSERT INTO Candidati VALUES ("A13", "Ferrara", "Baffoni");
INSERT INTO Candidati VALUES ("A21", "Torino", "Lorenzino");
INSERT INTO Candidati VALUES ("A21", "Roma", "Battistoni");

INSERT INTO Sondaggi VALUES ("A01", 50);
INSERT INTO Sondaggi VALUES ("A21", 30);
INSERT INTO Sondaggi VALUES ("A09", 10);
INSERT INTO Sondaggi VALUES ("A13", 31);
INSERT INTO Sondaggi VALUES ("A42", 2);

--2.a
SELECT PercFavorevoli 
FROM Sondaggi 
WHERE CodPart = 'A13'

--2.b
SELECT PercFavorevoli 
FROM Sondaggi S, Candidati C  
WHERE S.CodPart = C.CPartito 
	AND C.NomeCand = 'Rossi'

--2.c
SELECT NomePartito 
FROM Partiti P, Sondaggi S 
WHERE P.Codice = S.CodPart 
	AND S.PercFavorevoli = 30   

--2.d 
SELECT CodPart 
FROM Sondaggi 
WHERE PercFavorevoli > 20
