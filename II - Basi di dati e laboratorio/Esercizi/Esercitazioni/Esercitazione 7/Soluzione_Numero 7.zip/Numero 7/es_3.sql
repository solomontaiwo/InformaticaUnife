CREATE DATABASE Fiat;
USE Fiat;

CREATE TABLE Dipartimento (
	CodD INT NOT NULL, 
	NomeD VARCHAR(30),  
	Indirizzo VARCHAR(30), 
	Citta VARCHAR(30),
	
	PRIMARY KEY (CodD)	
); 

CREATE TABLE Impiegato (
	CodFisc VARCHAR(16) NOT NULL,
	Nome VARCHAR(30), 
	Cognome VARCHAR(30), 
	Recapito VARCHAR(20), 
	Dip INT,
	
	PRIMARY KEY (CodFisc),
	FOREIGN KEY (Dip) REFERENCES Dipartimento(CodD)
);

CREATE TABLE Progetto (
	CodP INT NOT NULL, 
	NomeP VARCHAR(30), 
	Budget INT,
	
	PRIMARY KEY (CodP)
);

CREATE TABLE Lavora_Su (
	Imp VARCHAR(16) NOT NULL, 
	Prog INT NOT NULL,
	
	PRIMARY KEY (Imp,Prog),
	FOREIGN KEY (Imp) REFERENCES Impiegato(CodFisc),
	FOREIGN KEY (Prog) REFERENCES Progetto(CodP)
);

INSERT INTO Dipartimento VALUES (100, 'Ricerca e Sviluppo', 'Via Giuseppe Verdi, 3', 'Torino');
INSERT INTO Dipartimento VALUES (200, 'Motore', 'Corso del Popolo, 44', 'Torino');
INSERT INTO Dipartimento VALUES (300, 'Infotainment', 'P.zza Pontida, 56', 'Torino');

INSERT INTO Impiegato VALUES ('PSQLBR71L13G676E', 'Alberto', 'Rossi', '345 9876543', 100);
INSERT INTO Impiegato VALUES ('MRBRBT72H23V123N', 'Roberto', 'Mirabelli', '349 123456', 200);
INSERT INTO Impiegato VALUES ('JHNSMT53H15G678C', 'John', 'Smith', '011 6706733', 300);
INSERT INTO Impiegato VALUES ('MSRVLR88F21V981H', 'Valeria', 'Mastroianni', '346 2134590', 200);

INSERT INTO Progetto VALUES (101, 'AW123F-23', 200000);
INSERT INTO Progetto VALUES (206, 'Motore elettrico', 80);
INSERT INTO Progetto VALUES (245, 'Motore diesel 3 litri 4 turbo', 10000000);
INSERT INTO Progetto VALUES (302, 'Integrazione nuovo iPhone X', 10000);

INSERT INTO Lavora_Su VALUES ('PSQLBR71L13G676E', 101);
INSERT INTO Lavora_Su VALUES ('MRBRBT72H23V123N', 206);
INSERT INTO Lavora_Su VALUES ('JHNSMT53H15G678C', 302);
INSERT INTO Lavora_Su VALUES ('MSRVLR88F21V981H', 206);
INSERT INTO Lavora_Su VALUES ('MSRVLR88F21V981H', 245);

--3.a
SELECT Nome 
FROM Impiegato 
WHERE Cognome='Rossi';

--3.b
SELECT D.NomeD
FROM Dipartimento D, Impiegato I, Lavora_Su L  
WHERE I.Dip = D.CodD 
	AND I.CodFisc = L.Imp 
	AND L.Prog = 245; 


--3.c
SELECT DISTINCT P.CodP, P.NomeP
FROM Progetto P, Lavora_Su L
WHERE L.Prog=P.CodP
	GROUP BY P.CodP, P.NomeP
	HAVING count(*) >= 2;


--3.d
SELECT Nome, Cognome 
FROM Impiegato 
WHERE Recapito = '011 6706733'; 
