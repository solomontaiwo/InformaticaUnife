class Conferenza:
    def __init__(self, nome, luogo):
        self._nome = nome
        self._luogo = luogo
        self._partecipanti = []

    def addPart(self, part):
        self._partecipanti.append(part)

    def getTot(self):
        tot = 0
        for p in self._partecipanti:
            tot = tot + p.getReg()
        return tot

    def partString(self):
        res = ""
        for p in self._partecipanti:
            res = res + p.toString()
        return res

    def toString(self):
        totale = self.getTot()
        partecipanti = self.partString()
        return self._nome + "\n" + self._luogo + "\n" + str(totale) + "\t" + str(len(self._partecipanti)) + "\n" + str(partecipanti)
