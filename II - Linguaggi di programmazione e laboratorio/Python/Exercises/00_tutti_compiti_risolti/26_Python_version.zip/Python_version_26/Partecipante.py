


class Partecipante:
    def __init__(self, codice, nome, cognome, tipo):
        self._codice = codice
        self._nome = nome
        self._cognome = cognome
        self._tipo = tipo

    def getTipo(self):
        return self._tipo

    def getCode(self):
        return self._codice

    def getCognome(self):
        return self._cognome

    def toString(self):
        return str(self._tipo) + "\t" + str(self._codice) + "\t" + self._nome + "\t" + self._cognome + "\t"
