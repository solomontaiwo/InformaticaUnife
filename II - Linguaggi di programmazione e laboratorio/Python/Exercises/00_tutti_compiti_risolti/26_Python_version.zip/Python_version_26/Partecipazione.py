class Partecipazione:
    def __init__(self, part, reg):
        self._part = part
        self._reg = reg

    def getReg(self):
        return self._reg

    def toString(self):
        return self._part.getCognome() + " " + str(self._reg)
