from Partecipante import Partecipante


class Regolare(Partecipante):
    def __init__(self, codice, nome, cognome, ente, dip, acc):
        super().__init__(codice, nome, cognome, "regolare")
        self._ente = ente
        self._dip = dip
        self._acc = acc

    def getEnte(self):
        return self._ente

    def toString(self):
        return super().toString() + "\t-\t-\t" + str(self._ente) + "\t" + str(self._dip) + "\t" + str(self._acc)
