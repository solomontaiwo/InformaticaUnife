from Partecipante import Partecipante


class Studente(Partecipante):
    def __init__(self, codice, nome, cognome, corso, universita, anno):
        super().__init__(codice,nome,cognome,"studente")
        self._corso = corso
        self._universita = universita
        self._anno = anno
        
    def getUni(self):
        return self._universita
    
    def toString(self):
        return super().toString() + self._corso + "\t" + self._universita + "\t" + str(self._anno) +  "-\t-\t-"