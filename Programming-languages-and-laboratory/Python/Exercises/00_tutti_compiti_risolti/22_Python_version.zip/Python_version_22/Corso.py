

class Corso:
    def __init__(self, c, n, d):
        self._codice = c
        self._nome = n
        self._docente = d


    def toString(self):
        return self._nome + "\t" + str(self._codice) + "\t" + self._docente + "\t"
