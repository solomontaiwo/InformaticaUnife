class Esame:
    def __init__(self, c, v):
        self._codice = c
        self._voto = v

    def getVotoAsInt(self):
        if(self._voto == "30L"):
            return 31
        else:
            return int(self._voto)

    def getVotoAsString(self):
        return self._voto

    def getCorso(self):
        return self._codice

    def toString(self):
        return "(" + str(self._codice) + "," + str(self._voto) + ")"
