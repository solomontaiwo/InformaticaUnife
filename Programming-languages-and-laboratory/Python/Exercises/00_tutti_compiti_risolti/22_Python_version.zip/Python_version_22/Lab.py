from Corso import Corso


class Lab(Corso):
    def __init__(self, c, n, d, lab, ass, post):
        super().__init__(c, n, d)
        self._lab = lab
        self._ass = ass
        self._post = post

    def toString(self):
        return super().toString() + "lab.\t-\t-\t-\t" + str(self._lab) + "\t" + str(self._ass) + "\t" + str(self._post)
