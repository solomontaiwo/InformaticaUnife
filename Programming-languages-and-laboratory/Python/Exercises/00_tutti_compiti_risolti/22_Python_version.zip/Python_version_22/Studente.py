from Esame import Esame


class Studente:
    def __init__(self, mat, nome):
        self._mat = mat
        self._nome = nome
        # lkl = LinkedList()
        # self._libretto = lkl
        self._libretto = []

    def getMat(self):
        return self._mat

    def getNome(self):
        return self._nome

    def addEsame(self, e):
        self._libretto.append(e)

    def votoMax(self):
        maxVote = 0
        # es = Esame()
        for e in self._libretto:
            if(e.getVotoAsInt() > maxVote):
                maxVote = e.getVotoAsInt()
                maxe = e
        return maxe

    def getMedia(self):
        tot = 0
        for e in self._libretto:
            tot = tot + e.getVotoAsInt()
        return (tot/len(self._libretto))

    def librString(self):
        res = ""
        for e in self._libretto:
            res = res + e.toString()
        return res

    def toString(self):
        media = self.getMedia()
        libretto = self.librString()
        return self._nome + "\t" + str(media) + "\t" + str(libretto)
