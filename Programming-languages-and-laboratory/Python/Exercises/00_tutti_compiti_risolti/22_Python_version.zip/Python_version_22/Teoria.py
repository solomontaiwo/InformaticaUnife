from Corso import Corso


class Teoria(Corso):
    def __init__(self, c, n, d, aula, ore, oreLez):
        super().__init__(c, n, d)
        self._aula = aula
        self._ore = ore
        self._oreLez = oreLez

    def toString(self):
        return super().toString() + "teoria\t" + self._aula + "\t" + self._ore + "\t" + self._oreLez + "\t-\t-\t-"
