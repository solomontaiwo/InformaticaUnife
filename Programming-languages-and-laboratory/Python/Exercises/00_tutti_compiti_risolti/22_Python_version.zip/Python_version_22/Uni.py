import sys
import argparse

from Corso import Corso
from Esame import Esame
from Lab import Lab
from Studente import Studente
from Teoria import Teoria


class Uni:
    def __init__(self, arg):
        self._arg = arg

    def main(self):
        corsi = []
        studenti = []
        nomeCorsi = {}

        try:
            f = open("corsi.txt", "r")
            line = f.readline().strip()

            while(line != ''):
                tok = line.split()
                cod = int(tok[0])
                tipo = tok[1]
                line = f.readline().strip()
                nome = line
                line = f.readline().strip()
                docente = line

                nomeCorsi[cod] = nome

                line = f.readline().strip()
                if(tipo == "teoria"):
                    tok = line.split()
                    aula = tok[0]
                    ore = tok[1]
                    oreLez = tok[2]
                    c = Teoria(cod, nome, docente, aula, ore, oreLez)
                    corsi.append(c)
                else:
                    lab = line
                    line = f.readline().strip()
                    ass = line
                    line = f.readline().strip()
                    posti = int(line)
                    c = Lab(cod, nome, docente, lab, ass, posti)
                    corsi.append(c)
                line = f.readline().strip()
                line = f.readline().strip()
            f.close()
        except IOError:
            print("IO Error finded.")
        except:
            print("Unexpected error:", sys.exc_info()[0])
            raise

        try:
            f = open("studenti.txt", "r")
            line = f.readline().strip()
            while(line != ''):
                mat = int(line)
                nome = f.readline().strip()
                s = Studente(mat, nome)
                studenti.append(s)
                line = f.readline().strip()
                while(line != '' and line != '\n'):
                    tok = line.split()
                    cod = int(tok[0])
                    voto = tok[1]
                    e = Esame(cod, voto)
                    s.addEsame(e)
                    line = f.readline().strip()
                line = f.readline().strip()
            f.close()
        except IOError:
            print("IO Error finded.")
        except:
            print("Unexpected error:", sys.exc_info()[0])
            raise

        print("nome, codice, docente, tipo, aula, ore sett., ore/lez., lab., assistente, postazioni\n")
        for c in corsi:
            print(c.toString())

        for s in studenti:
            print(s.toString())

        print("\n")

        for s in studenti:
            if(s.getMat() == int(self._arg)):
                maxe = s.votoMax()
                codc = maxe.getCorso()
                print(s.getNome() + " " +
                      nomeCorsi[codc] + " " + maxe.getVotoAsString())


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('matricola', action='store')
    matr = parser.parse_args()
    u = Uni(matr.matricola)
    u.main()
